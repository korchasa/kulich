**Description**

<!--
Briefly describe the problem you are having in a few paragraphs.
-->

**Relevant Nomad job specification file**

```
(paste your output here)
```

**Output of `levant version`:**

```
(paste your output here)
```

**Output of `consul version`:**

```
(paste your output here)
```

**Output of `nomad version`:**

```
(paste your output here)
```

**Additional environment details:**

**Debug log outputs from Levant:**

<!--
If the log fragment is particularly long, please paste it into a gist or
similar and paste the link here.
-->
