# Levant CircleCI
Levant is currently configured to use CircleCI to perform basic testing on commits and pull requests.

## CircleCI multi-file config
For details on setting up and using CircleCI multi-file config please refer to the [Vault circleci README.md](https://github.com/hashicorp/vault/blob/master/.circleci/README.md)
